

goloop rpc sendtx deploy ./contracts/build/libs/contract-verification-0.1.0-optimized.jar \
    --uri https://berlin.net.solidwallet.io/api/v3 \
    --key_store keystore-testing --key_password testing1. \
    --nid 7 --step_limit=100000000000 \
    --content_type application/java \
    --param version=v1


goloop rpc sendtx call \
    --method verify \
    --to cx8a0e64b6b5a84b3f65a9ca12b1e14fe4667ea80b \
    --uri https://berlin.net.solidwallet.io/api/v3 \
    --key_store keystore-testing --key_password testing1. \
    --nid 7 --step_limit=100000000000 \
    --param contract_address=cx03f38c36460b2e9ce68a67f83fc9608690b1f64e \
    --param zipped_source_code="0x123456789"


goloop rpc sendtx call \
    --method verify \
    --to cx84c88b975f60aeff9ee534b5efdb69d66d239596 \
    --uri https://berlin.net.solidwallet.io/api/v3 \
    --key_store keystore-testing --key_password testing1. \
    --nid 7 --step_limit=100000000000 \
    --param contract_address=cx03f38c36460b2e9ce68a67f83fc9608690b1f64e \
    --param website="" \
    --param team_name="" \
    --param short_description="" \
    --param long_description="" \
    --param p_rep_address="" \
    --param city="" \
    --param country="" \
    --param license="" \
    --param facebook="" \
    --param telegram="" \
    --param reddit="" \
    --param discord="" \
    --param steemit="" \
    --param twitter="" \
    --param youtube="" \
    --param github="" \
    --param keybase="" \
    --param wechat="" \
    --param zipped_source_code="0x123456789"


